import { FLOW_HEIGHT, FLOW_WIDTH, flattenWave, ribbonFrame, ribbonPath, type Point, type WaveFrame } from "./ribbonGeometry";
export type SceneMapping = { scale: number; x: number; y: number };
export type ParticleFrame = { x: number; y: number; radius: number; opacity: number };
export type AuroraRenderer = { resize: (width: number, height: number, dpr: number) => void; render: (seconds: number, updateLights?: boolean) => void; destroy: () => void };
const PARTICLES = [
  [.08,.18,1,.28,12,-24,8,2], [.14,.28,1.5,.22,-18,32,7,5],
  [.09,.68,2,.18,24,-40,10,3], [.22,.88,1.5,.30,-10,18,6,4],
  [.92,.22,1.5,.36,-18,32,9,6], [.86,.38,1,.26,12,-24,7,3],
  [.94,.64,2,.20,-10,18,10,7], [.88,.83,1.5,.32,24,-40,9,2],
  [.62,.08,1,.24,-18,32,6,1], [.55,.92,1.5,.28,12,-24,8,5],
];
export function sceneMapping(width: number, height: number): SceneMapping {
  const scale = Math.max(width / FLOW_WIDTH, height / FLOW_HEIGHT);
  return { scale, x: (width - FLOW_WIDTH * scale) / 2, y: (height - FLOW_HEIGHT * scale) / 2 };
}
export function cssToWorld(x: number, y: number, mapping: SceneMapping): Point { return [(x - mapping.x) / mapping.scale, (y - mapping.y) / mapping.scale]; }
// CSS ease-in-out cubic-bezier(.42,0,.58,1), alternate, original negative delays.
function ease(t: number): number {
  let low = 0, high = 1;
  for (let i = 0; i < 16; i++) {
    const m = (low + high) / 2, q = 1 - m;
    if (3 * q * q * m * .42 + 3 * q * m * m * .58 + m ** 3 < t) low = m; else high = m;
  }
  const m = (low + high) / 2;
  return 3 * (1 - m) * m * m + m ** 3;
}
export function particleFrames(seconds: number, width: number, height: number): ParticleFrame[] {
  return PARTICLES.map(([x,y,radius,opacity,dx,dy,duration,delay]) => {
    const phase = ((seconds + delay) / duration) % 2, drift = ease(phase <= 1 ? phase : 2 - phase);
    return { x: x * width + radius + dx * drift, y: y * height + radius + dy * drift, radius, opacity };
  });
}
function segmentDistance(point: Point, a: Point, b: Point): number {
  const dx = b[0] - a[0], dy = b[1] - a[1], length = dx * dx + dy * dy;
  const t = length ? Math.max(0, Math.min(1, ((point[0] - a[0]) * dx + (point[1] - a[1]) * dy) / length)) : 0;
  return Math.hypot(point[0] - a[0] - t * dx, point[1] - a[1] - t * dy);
}
export type WaveCoverage = readonly (readonly Point[])[];
export function waveCoverage(waves: readonly WaveFrame[]): WaveCoverage { return waves.filter(wave => wave.index < 2).map(flattenWave); }
export function particleVisibility(point: Point, waves: WaveCoverage): number {
  let visibility = 1;
  waves.forEach((points, index) => {
    let distance = Infinity;
    for (let i = 1; i < points.length; i++) distance = Math.min(distance, segmentDistance(point, points[i - 1], points[i]));
    const edge = Math.max(0, Math.min(1, (distance - [40,52][index]) / 8));
    visibility = Math.min(visibility, edge * edge * (3 - 2 * edge));
  });
  return visibility;
}
export function createParticleSprite(): HTMLCanvasElement {
  const sprite = document.createElement("canvas"); sprite.width = sprite.height = 32;
  const context = sprite.getContext("2d");
  if (context) {
    // CSS circle uses the farthest corner as radius, so preserve that exact footprint.
    const glow = context.createRadialGradient(16,16,0,16,16,16 * Math.SQRT2);
    glow.addColorStop(0,"#c3f9f1"); glow.addColorStop(.24,"rgba(157,233,229,.6)");
    glow.addColorStop(.52,"rgba(112,211,215,.2)"); glow.addColorStop(.75,"rgba(112,211,215,0)");
    context.fillStyle = glow; context.fillRect(0,0,32,32);
  }
  return sprite;
}
export function paintParticles(context: CanvasRenderingContext2D, particles: readonly ParticleFrame[], mapping: SceneMapping, waves: WaveCoverage, sprite: CanvasImageSource): void {
  for (const particle of particles) {
    const visibility = particleVisibility(cssToWorld(particle.x,particle.y,mapping),waves);
    if (visibility <= 0) continue;
    context.globalAlpha = particle.opacity * visibility;
    const size = particle.radius * 2;
    context.drawImage(sprite,particle.x - particle.radius,particle.y - particle.radius,size,size);
  }
  context.globalAlpha = 1;
}
export function rasterSizes(width: number, height: number, dpr: number) {
  const scale = Math.min(Math.max(dpr,1),1.5,2400 / width,1800 / height);
  return { particleWidth: Math.max(1,Math.round(width * scale)), particleHeight: Math.max(1,Math.round(height * scale)) };
}
export function createAuroraRenderer(scene: HTMLDivElement): AuroraRenderer | null {
  const particles = scene.querySelector<HTMLCanvasElement>("canvas[data-aurora-particles]");
  const paths = [...scene.querySelectorAll<SVGPathElement>("[data-aurora-ribbon]")];
  const context = particles?.getContext("2d",{alpha:true});
  if (!particles || !context || paths.length !== 3) return null;
  const sprite = createParticleSprite();
  let width = 1, height = 1, mapping = sceneMapping(1,1), coverage = waveCoverage([ribbonFrame(0,0),ribbonFrame(1,0)]), particlesVisible = true;
  return {
    resize(nextWidth,nextHeight,dpr) {
      width = Math.max(1,nextWidth); height = Math.max(1,nextHeight); mapping = sceneMapping(width,height);
      particlesVisible = window.innerWidth >= 1200 && window.innerHeight > 700;
      const sizes = rasterSizes(width,height,dpr); particles.width = sizes.particleWidth; particles.height = sizes.particleHeight;
    },
    render(seconds,updateLights = true) {
      if (updateLights) {
        const waves = [0,1].map(index => ribbonFrame(index,seconds));
        waves.forEach((wave,index) => paths[index].setAttribute("d",ribbonPath(wave)));
        coverage = waveCoverage(waves);
      }
      context.setTransform(1,0,0,1,0,0); context.clearRect(0,0,particles.width,particles.height);
      context.setTransform(particles.width / width,0,0,particles.height / height,0,0);
      if (particlesVisible) paintParticles(context,particleFrames(seconds,width,height),mapping,coverage,sprite);
    },
    destroy() { context.clearRect(0,0,particles.width,particles.height); },
  };
}
